﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;

namespace HelloServiceHost
{
  class Program
  {
    static void Main(string[] args)
    {

      //HelloService.HelloService client = new HelloService.HelloService();
      //label1.Text = client.GetData(int.Parse(textBox1.Text.ToString()));


      using (ServiceHost host = new ServiceHost(typeof(HelloService.HelloServiceClient)))
      {
        host.Open();
        Console.WriteLine("Host started @ " + DateTime.Now.ToString());
        Console.ReadLine();
      }
    }
  }
}
