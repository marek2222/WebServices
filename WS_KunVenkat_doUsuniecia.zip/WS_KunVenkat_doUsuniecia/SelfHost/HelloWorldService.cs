﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SelfHost
{
  public class HelloWorldService : IHelloWorldService
  {

    public string PokazWiadomosc(string wartosc)
    {
      return string.Format("Witaj " + wartosc);
    }
  }
}
